// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from 'firebase/auth';
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";


const firebaseConfig = {
  apiKey: "AIzaSyDC76xSTAoGD5FHFYItqYGhfm-aijIPgYQ",
  authDomain: "visioattend-bc454.firebaseapp.com",
  projectId: "visioattend-bc454",
  databaseURL : "https://visioattend-bc454-default-rtdb.asia-southeast1.firebasedatabase.app",
  storageBucket: "visioattend-bc454.appspot.com",
  messagingSenderId: "646030201745",
  appId: "1:646030201745:web:573aa35290ab9aecd48030"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth();
export const storage = getStorage();
export const db = getFirestore();