import { onAuthStateChanged } from "firebase/auth";
import { createContext, useEffect, useState } from "react";
import { auth } from "../firebase";

export const AuthContext = createContext();

export const AuthContextProvider = ({ children }) => {
    const [currentUser, setCurrentUser] = useState(null);
    const [authId, setAuthId] = useState('1bORedjeitbhpypgVz5U03QD26S2');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const unsub = onAuthStateChanged(auth, (user) => {
            setCurrentUser(user);
            setAuthId('1bORedjeitbhpypgVz5U03QD26S2');
            setLoading(false);
        });
        return () => {
            unsub();
        };
    }, []);

    return (
        <AuthContext.Provider value={{ currentUser, authId, loading }}>
            {!loading && children}
        </AuthContext.Provider>
    );
};
