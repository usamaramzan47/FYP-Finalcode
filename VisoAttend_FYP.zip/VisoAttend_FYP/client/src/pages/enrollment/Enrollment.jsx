import React, { useEffect, useState } from 'react'
import Select from '../../components/global/selectinput/Select'
import Button from '../../components/global/button/Button'
import Prompt from '../../components/global/promptMsg/PromptMsg.jsx';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth, storage } from '../../firebase.js';
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { getDatabase, ref as dbRef, update, set, get } from "firebase/database";

function Enrollment() {

  const [err, setErr] = useState("");
  const [imgStatus, setImgStatus] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [progressBar, setProgress] = useState(0);
  const [previewUrl, setPreviewUrl] = useState('');
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    email: '',
    password: '',
    courses: [],
    img_file: null,
  });

  useEffect(() => {
    // handleSelection();

  }, []);

  const handleSelectionChange = (selectedItems) => {
    setFormData({
      ...formData,
      courses: selectedItems,
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData({
      ...formData,
      img_file: file,
    });

    const reader = new FileReader();
    reader.onloadend = () => {
      setPreviewUrl(reader.result);
    };
    if (file) {
      reader.readAsDataURL(file);
    }
  };



  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsOpen(true);
    setImgStatus("Uploading new record..");

    const studentId = formData.id.toUpperCase();
    const displayName = formData.name;
    const studentEmail = formData.email;
    const password = formData.password;
    const courseNames = formData.courses;
    const img = formData.img_file;

    const originalUser = auth.currentUser;
    const originalEmail = originalUser.email;
    const originalPassword = prompt("Please enter your password to confirm changes:");

    // check if user press cancel button
    if (!originalPassword) {
      setIsOpen(false);
      setImgStatus("");
      return;
    }
    try {

      const res = await createUserWithEmailAndPassword(auth, studentEmail, password);
      for (const courseName of courseNames) {
        const storageRef = ref(storage, `${courseName}/${studentId}`);
        const uploadTask = uploadBytesResumable(storageRef, img);

        uploadTask.on('state_changed',
          (snapshot) => {
            const progress = Math.ceil((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
            setProgress(progress)
            setImgStatus(`Uploading new user ${progress - 1}% done`);
          },
          (error) => {
            console.error(error);
            setImgStatus(`Unable to upload the image`);
            setErr(error);
          },
          async () => {
            try {
              const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
              const database = getDatabase();
              const studentRef = dbRef(database, `students/${studentId}`);

              set(studentRef, {
                id: studentId,
                displayName: displayName,
                email: studentEmail,
                photoURL: downloadURL,
                courses: courseNames,
              });


              const courseRef = dbRef(database, `courses/${courseName}/enrollStudents`);
              const datesRef = dbRef(database, `courses/${courseName}/dates`);
              const datesSnapshot = await get(datesRef);
              const dates = datesSnapshot.exists() ? datesSnapshot.val() : [];

              const attendance = dates.length > 0 ? new Array(dates.length).fill('-') : [];

              update(courseRef, {
                [studentId]: {
                  name: displayName,
                  photoURL: downloadURL,
                  attendance: attendance,
                },

              });
              const enrollUpdateRef = dbRef(database, `courses/${courseName}`);
              update(enrollUpdateRef, {
                newEnroll: true
              });

              await updateProfile(res.user, {
                displayName,
                photoURL: downloadURL,
              });

              setImgStatus(`Uploaded successfully`);
              setProgress(0)
            }
            catch (error) {
              console.error(error);
              setImgStatus(`Unable to upload the image`);
              setErr(error);
              setProgress(0)
            }
          }
        );
      }
      // Re-authenticate the original user
      await signInWithEmailAndPassword(auth, originalEmail, originalPassword);

    } catch (error) {
      console.error(error);
      setErr(error);
      setProgress(0)
    }
  };

  return (
    <div className='flex'>
      <div className="wrapper w-full p-4 flex flex-col gap-8">
        <span className='font-bold text-3xl'>New Record</span>
        <form className="box flex flex-col gap-5" onSubmit={handleSubmit}>
          <div className="w-[80%] flex flex-wrap gap-6">
            <Select
              label={"Userid"}
              type={"input"}
              name={"id"}
              placeholder={"enter user id..."}
              styles={"w-[25rem]"}
              onSelectionChange={handleInputChange}
            />
            <Select
              label={"Name"}
              type={"input"}
              name={"name"}
              placeholder={"enter full name..."}
              styles={"w-[25rem]"}
              onSelectionChange={handleInputChange}
            />
            <Select
              label={"Email"}
              type={"input"}
              name={"email"}
              placeholder={"enter email..."}
              styles={"w-[25rem]"}
              onSelectionChange={handleInputChange}
            />
            <Select
              label={"Password"}
              type={"input"}
              name={"password"}
              placeholder={"enter password..."}
              styles={"w-[25rem]"}
              onSelectionChange={handleInputChange}
            />
            <Select
              label={"Course"}
              type={"select"}
              name={"course"}
              styles={"w-[25rem]"}
              onSelectionChange={handleSelectionChange}
            />
            <div className="flex items-center justify-center w-full">
              <label
                htmlFor="dropzone-file"
                className={`flex flex-col items-center justify-center ${previewUrl === '' ? "w-full" : "w-max"} h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600`}
              >
                {!previewUrl && <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <svg
                    className="w-8 h-8 mb-4 text-gray-500 dark:text-gray-400"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 20 16"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"
                    />
                  </svg>
                  <p className="mb-2 text-sm text-gray-500 dark:text-gray-400">
                    <span className="font-semibold">Click to upload</span> or drag and drop
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    SVG, PNG, JPG or GIF (MAX. 800x400px)
                  </p>
                </div>}
                {previewUrl && (
                  <div className="w-full flex flex-col gap-2 px-10">
                    <span className='text-gray-500'>Selected Picture</span>
                    <img src={previewUrl} alt="Preview" className="w-32 h-32 object-cover rounded-full" />
                  </div>
                )}
                <input id="dropzone-file" type="file" className="hidden" name='img_file' required onChange={handleFileChange} />
              </label>
            </div>

          </div>
        
          <Button type={"primary"} label={"Create"} styles={`px-5`} />
        </form>
      </div>
      {isOpen && <Prompt message={err !== "" ? err.message : imgStatus} confirmed={setIsOpen} />}
    </div>
  )
}

export default Enrollment
