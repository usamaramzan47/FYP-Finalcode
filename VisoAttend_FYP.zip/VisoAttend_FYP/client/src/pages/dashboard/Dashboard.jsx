import React from 'react'
import Card from '../../components/card/Card'
import Table from '../../components/table/Table';
import ProfileCard from '../../components/profileCard/ProfileCard';
import Notifications from '../../components/notifications/Notifications';

function Dashboard() {
  const data = [
    {
      id: 1,
      name: "Anna Becker",
      img: "/images/a.jpg",
      mail: "anna@gmail.com",
      joinDate: "08/11/2019",
      designation: "Data manager"
    },
    {
      id: 2,
      name: "Angel Petel",
      img: "/images/b.jpg",
      mail: "angel@gmail.com",
      joinDate: "19/12/2020",
      designation: "Marketing Manager"
    },
    {
      id: 3,
      name: "John doi",
      img: "/images/c.jpg",
      mail: "john@gmail.com",
      joinDate: "25/01/2023",
      designation: "Data Analyistic"
    },
    {
      id: 4,
      name: "Alexa bay",
      img: "/images/a.jpg",
      mail: "alexa@gmail.com",
      joinDate: "04/07/2024",
      designation: "Project manager"
    },
  ]
  const tableHeading = [
    {
        id:1,
        label:'User'
    },
    {
        id:2,
        label:'Email'
    },
    {
        id:3,
        label:'Join Date'
    },
    {
        id:4,
        label:'Designation'
    },
];

  return (
    <section className='flex w-full border-black'>
      <main className="flex ">
        <div className="left flex flex-col justify-between">
          <div className="top flex gap-10 p-3 flex-wrap">
            <Card title="Reserved Rooms" value="26" total="/30" type="primary" img="/icons/classroom.svg" />
            <Card title="Admin Users" value="4" img="/icons/user.svg" />
            <Card title="Admin Users" value="4" img="/icons/user.svg" />
            <Card title="Admin Users" value="4" img="/icons/user.svg" />
            <Card title="Admin Users" value="4" img="/icons/user.svg" />
            <Card title="Admin Users" value="4" img="/icons/user.svg" />
          </div>
          <div className="bottom p-5 flex flex-col gap-3">
            <span className='font-semibold'>Admin users</span>
            <hr />
            <Table dataArray={data} tableHeading={tableHeading}/>
          </div>
        </div>
        <div className="right w-[45%] ">
          <div className="top p-2">
            <ProfileCard />
          </div>
          <div className="bottom p-2">
            < Notifications />
          </div>
        </div>

      </main>
    </section>
  )
}

export default Dashboard
