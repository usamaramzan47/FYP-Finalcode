import React, { useEffect, useState, useContext } from 'react'
import Card from '../../components/card/Card'
import { getDatabase, ref, get, onValue } from 'firebase/database';
import { AuthContext } from '../../context/AuthContext';
import ProfileCard from "../../components/profileCard/ProfileCard"

function Dashboard() {

    const { currentUser } = useContext(AuthContext);
    const [err, setError] = useState('');
    const [data, setData] = useState(null);
    const [coursesCount, setCourseCount] = useState(null);
    const [id, setId] = useState('');


    // read ID from email address
    const handleExtractId = (email) => {
        if (typeof email !== 'string') {
            console.error('Email is not a string:', email);
            return;
        }

        // Trim the email to remove any leading or trailing spaces
        const trimmedEmail = email.trim();
        const atIndex = trimmedEmail.indexOf('@');
        if (atIndex === -1) {
            console.error('Invalid email format, "@" not found:', trimmedEmail);
            return;
        }

        const extractedId = trimmedEmail.substring(0, atIndex);
        const capitalizedId = capitalizeFirstChar(extractedId);
        setId(capitalizedId);
    };

    const capitalizeFirstChar = (str) => {
        if (typeof str !== 'string' || str.length === 0) {
            return str; // handle invalid input
        }
        return str.charAt(0).toUpperCase() + str.slice(1);
    };

    useEffect(() => {
        if (!currentUser) {
            console.log("User is not authenticated");
            return;
        }
        handleExtractId(currentUser.email);
    }, [currentUser]);

    useEffect(() => {
        if (!id) {
            console.log("ID not set yet");
            return;
        }
        const database = getDatabase();
        const dataRef = ref(database, `students/${id}`); 
        const coursesRef = ref(database, `courses`); 
        const unsubscribe = onValue(dataRef, async (snapshot) => {
            const data = snapshot.val();
            setData(data);

            //fetch courses
            try {
                const snapshot = await get(coursesRef);
                if (snapshot.exists()) {
                    const coursesData = snapshot.val();

                    if (typeof coursesData === 'object') {
                        const length = Object.keys(coursesData).length;
                        setCourseCount(length);
                    } else {
                        setError('Unexpected data format');
                    }
                } else {
                    console.log("No data available");
                    setCourseCount(0);
                }
            } catch (error) {
                setError("Error fetching Courses data.", error.message);
            }
        }, (error) => {
            setError("Error fetching data.", error.message);
        });

        return () => unsubscribe(); // Clean up the listener on unmount
    }, [id]);

    return (
        <section className='flex flex-col justify-between gap-10 h-[85dvh] w-full border-black'>
            <main className="flex justify-between w-full">
                <div className="left flex flex-col justify-between">
                    {!err && <div className="top flex gap-10 p-3 flex-wrap">
                        <Card title="Register Course" value={data?.courses.length} total={`/${coursesCount ? coursesCount : 0}`} type="primary" img="/icons/classroom.svg" />
                        <Card title="Register Course" value={data?.courses.length} total={`/${coursesCount ? coursesCount : 0}`} type="primary" img="/icons/classroom.svg" />
                        <Card title="Register Course" value={data?.courses.length} total={`/${coursesCount ? coursesCount : 0}`} type="primary" img="/icons/classroom.svg" />

                    </div>}
                    {err && <span>{err}</span>}
                </div>
                <div className="mr-5">
                    <ProfileCard />
                </div>
            </main>
            <marquee className="border-y border-black border-dashed" width="100%" direction="left" height="100px">
                <blink>

                    <span className='text-8xl font-bold text-blue-200'>
                        <span className='text-8xl font-bold text-green-400'>V</span>ISIO <span className='text-8xl font-bold text-[#6956E5]'>A</span>TTEND</span>
                </blink>
            </marquee>
        </section>
    )
}

export default Dashboard
