import React from 'react'

function ReservedRooms() {
    const room = [
        {
            id: 1,
            roomNum: '318',
            building: 'STD',
            status: 'reserved'
        },
        {
            id: 2,
            roomNum: '302',
            building: 'STD',
            status: 'vacant'
        },
        {
            id: 3,
            roomNum: '303',
            building: 'STD',
            status: 'vacant'
        },
        {
            id: 4,
            roomNum: '301',
            building: 'STD',
            status: 'vacant'
        },
        {
            id: 5,
            roomNum: '302',
            building: 'STD',
            status: 'vacant'
        },
        {
            id: 6,
            roomNum: '303',
            building: 'STD',
            status: 'vacant'
        },
        {
            id: 7,
            roomNum: '301',
            building: 'STD',
            status: 'vacant'
        },
        {
            id: 8,
            roomNum: '302',
            building: 'STD',
            status: 'vacant'
        },
        {
            id: 9,
            roomNum: '303',
            building: 'STD',
            status: 'vacant'
        },
        {
            id: 10,
            roomNum: '301',
            building: 'STD',
            status: 'vacant'
        },
        {
            id: 11,
            roomNum: '302',
            building: 'STD',
            status: 'vacant'
        },
        {
            id: 12,
            roomNum: '303',
            building: 'STD',
            status: 'vacant'
        },
    ]
    return (
        <div className='flex w-full'>
            <div className="wrapper w-full px-4 flex flex-col h-[86vh] overflow-y-scroll">
                <div className="flex h-full gap-5 flex-col justify-between ">
                    <span className='text-3xl font-bold fixed  w-full bg-white pb-2'>Resrved Rooms</span>
                    <div className="wrap flex flex-col gap-5 mt-14">
                        {
                            room.map(item => (
                                <div id={item.id} className={`box cursor-pointer flex w-full min-h-16 rounded-md ${item.status === 'reserved' ? 'bg-green-300' : "bg-[#f9f0f0ee]"} px-1`}>
                                    <div className="left p-1 flex flex-col justify-between">
                                        <span className='text-sm font-bold'>Room No.{item.roomNum}</span>
                                        <div className="status flex gap-4">
                                            <div className="item flex items-center gap-1 rounded-md px-1 bg-[#F0E8D9]">
                                                <img src="/icons/building.svg" alt="building" className='w-4 h-4' />
                                                <span className='text-[12px] text-black'>{item.building}</span>
                                            </div>
                                            <div className="item flex items-center">
                                                <img src="/icons/reservedroom.svg" alt="building" className='w-4 h-4' />
                                                <span className='text-[12px]'>{item.status}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="left"></div>
                                </div>
                            ))
                        }
                    </div>
                </div>
            </div>

        </div>
    )
}

export default ReservedRooms
