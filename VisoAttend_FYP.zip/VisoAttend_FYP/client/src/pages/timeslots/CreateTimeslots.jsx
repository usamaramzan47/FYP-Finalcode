import React, { useState } from 'react'
import Button from '../../components/global/button/Button'
import TimePicker from 'react-time-picker';
import 'react-time-picker/dist/TimePicker.css';
import 'react-clock/dist/Clock.css';
import './style.css'
import { ref, set, getDatabase, update, get } from 'firebase/database';


function CreateTimeslots() {

    const [times, setTimes] = useState({
        startTime: '10:00',
        endTime: '10:01',
        duration: '00:01'
    });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false); // Add loading state


    const onChangeStartTime = (value) => {
        if (isValidTime(value)) {
            setTimes((prevTimes) => {
                const newTimes = { ...prevTimes, startTime: value || '00:00' };
                const duration = calculateDuration(newTimes.startTime, newTimes.endTime);
                if (duration === 'Invalid Time') {
                    setError('Invalid time selection. End time cannot be less than start time.');
                } else if (duration === '00:00') {
                    setError('Invalid time selection. The class duration should be at least 1 minute.');
                } else {
                    newTimes.duration = duration;
                    setError('');
                }
                return newTimes;
            });
        } else {
            setError('Invalid time selection. Time must be between 00:00 and 17:00.');
        }
    };

    const onChangeEndTime = (value) => {
        if (isValidTime(value)) {
            setTimes((prevTimes) => {
                const newTimes = { ...prevTimes, endTime: value || '00:00' };
                const duration = calculateDuration(newTimes.startTime, newTimes.endTime);
                if (duration === 'Invalid Time') {
                    setError('Invalid time selection. End time cannot be less than start time.');
                } else if (duration === '00:00') {
                    setError('Invalid time selection. The class duration should be at least 1 minute.');
                } else {
                    newTimes.duration = duration;
                    setError('');
                }
                return newTimes;
            });
        } else {
            setError('Invalid time selection. Time must be between 00:00 and 17:00.');
        }
    };

    const isValidTime = (time) => {
        if (!time) return false;
        const [hours, minutes] = time.split(':').map(Number);
        return hours >= 0 && hours <= 17 && minutes >= 0 && minutes < 60;
    };

    const calculateDuration = (start, end) => {
        if (!start || !end) return '00:00';

        const [startHours, startMinutes] = start.split(':').map(Number);
        const [endHours, endMinutes] = end.split(':').map(Number);

        let durationMinutes = (endHours * 60 + endMinutes) - (startHours * 60 + startMinutes);
        if (durationMinutes < 0) {
            return 'Invalid Time'; // Handle invalid time case
        }

        const hours = Math.floor(durationMinutes / 60);
        const minutes = durationMinutes % 60;

        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    };
    const checkOverlap = (newStartTime, newEndTime, existingStartTime, existingEndTime) => {
        return newStartTime < existingEndTime && newEndTime > existingStartTime;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        const database = getDatabase();
        const timeSlotsRef = ref(database, 'timeslots');

        try {
            const snapshot = await get(timeSlotsRef);
            if (snapshot.exists()) {
                const existingTimeSlots = snapshot.val();
                const newStartTime = convertToMinutes(times.startTime);
                const newEndTime = convertToMinutes(times.endTime);

                for (const key in existingTimeSlots) {
                    const existingSlot = existingTimeSlots[key];
                    const existingStartTime = convertToMinutes(existingSlot.startTime);
                    const existingEndTime = convertToMinutes(existingSlot.endTime);

                    if (checkOverlap(newStartTime, newEndTime, existingStartTime, existingEndTime)) {
                        setError('Time slot overlaps with an existing one.');
                        setLoading(false);
                        return;
                    }
                }

                const newIndex = Object.keys(existingTimeSlots).length;
                const updates = {};
                updates[`${newIndex}`] = times;
                await update(timeSlotsRef, updates);
            } else {
                await set(timeSlotsRef, [times]);
            }

            alert('Timeslot saved successfully!');
        } catch (error) {
            setError('Error saving timeslot.');
        } finally {
            setLoading(false); // Set loading to false after completion
        }
    };

    const convertToMinutes = (time) => {
        if (!time) return 0;
        const [hours, minutes] = time.split(':').map(Number);
        return hours * 60 + minutes;
    };


    return (
        <div className='flex w-full'>
            <div className="wrapper flex flex-col w-full">
                <form className="top bg-[#f8f8f8] flex-1 p-4 flex flex-col gap-10 justify-between" onSubmit={handleSubmit}>
                    <span className="title font-bold text-lg">New TimeSlots</span>
                    <div className="selectWrapper flex justify-between gap-10 w-[80%] flex-wrap">
                        <div className="item flex flex-col">
                            <label htmlFor={"startTime"} className='text-14 text-[#979696] font-semibold'>Enter Start Time</label>
                            <TimePicker
                                onChange={onChangeStartTime}
                                value={times.startTime}
                                clearIcon={null}
                                hourPlaceholder={"HH"}
                                minutePlaceholder={"MM"}
                                format="HH:mm"
                                name='startTime'
                            />
                        </div>
                        <div className="item flex flex-col">
                            <label htmlFor={"endTime"} className='text-14 text-[#979696] font-semibold'>Enter End Time</label>
                            <TimePicker
                                onChange={onChangeEndTime}
                                value={times.endTime}
                                clearIcon={null}
                                hourPlaceholder={"HH"}
                                minutePlaceholder={"MM"}
                                format="HH:mm"
                                name='endTime'
                            />
                        </div>
                        <div className="item flex flex-col">
                            <label htmlFor={"duration"} className='text-14 text-[#979696] font-semibold'>Total Class Time</label>
                            <input
                                type="text"
                                value={times.duration}
                                readOnly
                                className="custom_input"
                                name='duration'
                            />
                        </div>
                    </div>
                    {error && <div className="error text-red-500">{error}</div>}
                    {loading &&
                        <div className="loading  flex gap-2 items-center ">Loading...
                            <img src="/icons/spinning-dots.svg" alt="loading" className=' h-12 w-12 mr-3' />
                        </div>}
                    <Button type={"primary"} label={"Create Slot"} styles={`w-32 p-2 rounded-lg ${error && "cursor-not-allowed bg-gray-300"} ${loading && "cursor-not-allowed bg-gray-300"}`} disabled={error ? true : false} />
                </form>

            </div>
        </div>
    )
}

export default CreateTimeslots
