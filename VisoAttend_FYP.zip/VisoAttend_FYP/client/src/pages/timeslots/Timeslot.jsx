import React, { useState } from 'react'
import Select from '../../components/global/selectinput/Select'
import Button from '../../components/global/button/Button'
import Table from '../../components/table/Table'
import { ref, set, getDatabase, update, get } from 'firebase/database';


function Timeslot() {

    const [loading, setLoading] = useState(false); // Add loading state
    const [error, setError] = useState('');

    // dummy data for available room
    const data = [
        {
            id: 1,
            building: "STD",
            roomNumber: 'STD-301',
            timeSlot: "8:00-10:00",
        },
        {
            id: 2,
            building: "STD",
            roomNumber: 'STD-310',
            timeSlot: "11:00-12:15",
        },
        {
            id: 3,
            building: "STD",
            roomNumber: 'STD-609',
            timeSlot: "12:00-2:15",
        },
        {
            id: 4,
            building: "STD",
            roomNumber: 'STD-609',
            timeSlot: "12:00-2:15",
        },
        {
            id: 5,
            building: "STD",
            roomNumber: 'STD-609',
            timeSlot: "12:00-2:15",
        },
        {
            id: 6,
            building: "STD",
            roomNumber: 'STD-609',
            timeSlot: "12:00-2:15",
        },
        {
            id: 7,
            building: "STD",
            roomNumber: 'STD-609',
            timeSlot: "12:00-2:15",
        },
        {
            id: 8,
            building: "STD",
            roomNumber: 'STD-609',
            timeSlot: "12:00-2:15",
        },
    ]
    const tableHeading = [
        {
            id: 1,
            label: 'Building'
        },
        {
            id: 2,
            label: 'Room Number'
        },
        {
            id: 3,
            label: 'Time Slots'
        },
    ];
    const calculateDuration = (start, end) => {
        if (!start || !end) return '00:00:00';

        const [startHours, startMinutes] = start.split(':').map(Number);
        const [endHours, endMinutes] = end.split(':').map(Number);

        let durationMinutes = (endHours * 60 + endMinutes) - (startHours * 60 + startMinutes);
        if (durationMinutes < 0) {
            return 'Invalid Time'; // Handle invalid time case
        }

        const hours = Math.floor(durationMinutes / 60);
        const minutes = durationMinutes % 60;

        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:00`;
    };

    const convertToMinutes = (time) => {
        if (!time) return 0;
        const [hours, minutes] = time.split(':').map(Number);
        return hours * 60 + minutes;
    };

    const checkOverlap = (newStartTime, newEndTime, existingStartTime, existingEndTime) => {
        return newStartTime < existingEndTime && newEndTime > existingStartTime;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const room = e.target.room.value;
        const timeslot = e.target.timeslot.value;
        const teacher = e.target.teacher.value;
        const course = e.target.course.value;

        // Validate that the field is not empty
        if (room === 'select') {
            setError('room field is required');
            return;
        }
        if (timeslot === 'select') {
            setError('timeslot field is required');
            return;
        }
        if (teacher === 'select') {
            setError('Teacher field is required');
            return;
        }
        if (course === 'select') {
            setError('Course field is required');
            return;
        }


        setError(''); // Clear any previous errors

        const [startTime, endTime] = timeslot.split("-");

        try {
            setLoading(true)
            // calculate duration from start to end time
            const class_duration_minutes = calculateDuration(startTime.trim(), endTime.trim())

            const newFormData = ({
                class_duration_minutes,
                courseId: course,
                end_time: endTime,
                section: 'V1',
                start_time: startTime,
                teacher,
            });

            // push data to firebase
            const database = getDatabase();

            const timeSlotsRef = ref(database, `ReserveRoom/${room}/timeSlots`);
            const snapshot = await get(timeSlotsRef);
            const existingTimeSlots = snapshot.val();

            // check for overlap class schedule


            if (snapshot.exists()) {
                const existingTimeSlots = snapshot.val();
                const newStartTime = convertToMinutes(startTime);
                const newEndTime = convertToMinutes(endTime);

                for (const key in existingTimeSlots) {
                    const existingSlot = existingTimeSlots[key];

                    const existingStartTime = convertToMinutes(existingSlot.start_time);
                    const existingEndTime = convertToMinutes(existingSlot.end_time);

                    if (checkOverlap(newStartTime, newEndTime, existingStartTime, existingEndTime)) {
                        setError('Time slot overlaps with an existing one.');
                        setLoading(false);
                        return;
                    }
                }

            }
            // Calculate the length of the timeSlots data
            const timeSlotsLength = existingTimeSlots ? Object.keys(existingTimeSlots).length : 0;

            // Create a new key for the time slot
            const newKey = `slot${timeSlotsLength + 1}`;

            // Save the new time slot data with the generated key
            await set(ref(database, `ReserveRoom/${room}/timeSlots/${newKey}`), newFormData);

            alert('Timeslot saved successfully!');

        } catch (error) {
            console.error('Error saving data to Firebase', error.message);
        } finally {
            setLoading(false); // Set loading to false after completion
        }

    };



    return (
        <div className='flex w-full '>
            <div className="wrapper flex flex-col h-[86vh] w-full">
                <form className="top bg-[#f8f8f8] flex-1 p-4 flex flex-col justify-between" method='get' onSubmit={handleSubmit}>
                    <span className="title font-bold text-lg">Reserved Room</span>
                    <div className="selectWrapper flex justify-between gap-10 w-[80%] flex-wrap">
                        <div className="item flex flex-col">
                            <Select label={"Room No."} type={"simple select"} name={"room"} />
                        </div>
                        <div className="item flex flex-col">
                            <Select label={"Timeslot"} type={"simple select"} name={"timeslot"} />
                        </div>
                        <div className="item flex flex-col">
                            <Select label={"Teacher"} type={"simple select"} name={"teacher"} />
                        </div>
                        <div className="item flex flex-col">
                            <Select label={"Course"} type={"simple select"} name={"course"} />
                        </div>
                    </div>

                    {error && <div className="error text-red-500 font-semibold flex gap-4 items-center px-2 rounded-lg justify-between w-3/4 bg-red-100">
                        {error}
                        <span className='font-bold text-xl cursor-pointer p-2' onClick={() => { setError('') }}>X</span>
                    </div>}
                    {loading &&
                        <div className="loading  flex gap-2 items-center ">Loading...
                            <img src="/icons/spinning-dots.svg" alt="loading" className=' h-12 w-12 mr-3' />
                        </div>}
                    <Button type={"primary"} label={"Reserve Slot"} styles={`w-32 p-2 rounded-lg ${error && "cursor-not-allowed bg-gray-300"} ${loading && "cursor-not-allowed bg-gray-300"}`} disabled={error ? true : false} />
                </form>
                <div className="bottom flex-1 flex flex-col font-bold overflow-y-scroll">
                    <label className='p-3 text-16 sticky top-0 bg-white'>Available Rooms</label>
                    <Table dataArray={data} tableHeading={tableHeading} styles={"w-[80%] p-3"} />
                </div>
            </div>
        </div>
    )
}

export default Timeslot
