import React, { useEffect, useRef, useState } from 'react'
import Select from '../../components/global/selectinput/Select';
import Table from '../../components/table/Table';
import { ref, onValue, getDatabase } from 'firebase/database';

function AttendancePage(props) {
    const [selectedCourse, setSelectedCourse] = useState(null);
    const [isOpenLiveAttend, setIsOpenLiveAttend] = useState(false);
    const [dataa, setData] = useState([]); // Use state to hold the fetched data
    const [searchId, setSearchId] = useState('');
    const [err, setError] = useState('');
    const [displayRecordIndex, setDisplayRecordIndex] = useState({
        id: '',
        index: '',
        name: '',
        img: '',
        attend: null,
    });
    const liveViewRef = useRef(null);

    const [data, setDataa] = useState([{
        id: '',
        name: '',
        attendance: [],
        photoURL: ''
    }]);
    const [tableHeading, setLacDate] = useState([
        {
            id: 1,
            label: "ID",
        },
        {
            id: 2,
            label: "Name",
        },

    ]);
    const [timeRecord, setTimeRecord] = useState([]);

    // handle Data fetch
    useEffect(() => {

        if (selectedCourse !== null) {
            const database = getDatabase();
            const dbRef = ref(database, `courses/${selectedCourse}`);

            onValue(dbRef, (snapshot) => {
                const dataa = snapshot.val();
                if (!dataa) {
                    setError("No data found for the selected course")
                    return;
                }

                const attendanceData = Object.values(dataa);
                setData(attendanceData);

                // Process lecture dates
                try {
                    if (attendanceData.length > 1 && Array.isArray(attendanceData[1])) {
                        const lDate = attendanceData[1];
                        const lectureDate = lDate.map((date, index) => ({
                            id: tableHeading.length + index + 1, // Ensure unique IDs
                            label: `L${index + 1}`,
                            date: date
                        }));

                        setLacDate(prevTableHeading => {
                            // Filter out previous lecture dates
                            const initialColumns = prevTableHeading.filter(item => item.label === "ID" || item.label === "Name");
                            const newUniqueDates = lectureDate.filter(item => !initialColumns.some(col => col.date === item.date));
                            return [...initialColumns, ...newUniqueDates];
                        });

                    } else {
                        throw new Error("Lecture dates data is not an array");
                    }
                } catch (error) {
                    setError("Class attendance is not scheduled.", error)

                }
                // Process enrolled students and their attendance
                try {
                    if (attendanceData.length > 2 && typeof attendanceData[2] === 'object') {
                        const enrollStudents = attendanceData[2];
                        const updatedData = Object.keys(enrollStudents).map(key => {
                            const nestedObject = enrollStudents[key];
                            return { id: key, name: nestedObject.name, photoURL: nestedObject.photoURL, attendance: nestedObject.attendance ? nestedObject.attendance : ['-'] };
                        });

                        // set data for all users
                        if (!props.id)
                            setDataa(updatedData);
                        // set data for specfic student portal
                        else {
                            let filteredData = updatedData.filter(item => item.id === props.id);
                            setDataa(filteredData);
                        }
                    } else {
                        throw new Error("Enrolled students data is not an object");
                    }
                } catch (error) {
                    setError("No enrollStudents Data Found!", error.message);

                }
            });
        }
    }, [selectedCourse]);

    // handle outside click
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (liveViewRef.current && !liveViewRef.current.contains(event.target)) {
                setIsOpenLiveAttend(false);
            }
        };

        if (isOpenLiveAttend) {
            document.addEventListener('mousedown', handleClickOutside);
        } else {
            document.removeEventListener('mousedown', handleClickOutside);
        }

        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [isOpenLiveAttend]);


    const handleKeyPress = (event) => {
        if (event.key === 'Enter') {
            handleSearch();
        }
    }

    const handleSearch = () => {
        const inputFieldValue = document.querySelector('.searchInput').value.toUpperCase();
        const findValue = data.find(item => item.id === inputFieldValue)
        findValue ? setSearchId(findValue.id) : setSearchId('no record!');
    }
    const handleOpenLive = () => {
        setIsOpenLiveAttend(!isOpenLiveAttend)
    }

    // process in/out time for students

    const mergeArrays = (inTime, outTime) => {
        const mergedArray = [];
        const maxLength = Math.max(inTime.length, outTime.length);

        for (let i = 0; i < maxLength; i++) {
            if (i < inTime.length) {
                mergedArray.push(inTime[i]);
            }
            if (i < outTime.length) {
                mergedArray.push(outTime[i]);
            }
        }

        return mergedArray;
    };
    const getStudentTimesById = (data, studentId) => {
        const enrollStudentsRecord = data[2];

        if (!enrollStudentsRecord[studentId]) {
            console.error(`Student with ID ${studentId} not found`);
            return null;
        }

        try {

            const nestedObject = enrollStudentsRecord[studentId];
            const inTime = nestedObject.in_Time ? nestedObject.in_Time[displayRecordIndex.index] : [0];
            const outTime = nestedObject.out_Time ? nestedObject.out_Time[displayRecordIndex.index] : [0];
            return mergeArrays(inTime, outTime);

        } catch (error) {

            setError(error.message);
        }
    };

    useEffect(() => {
        if (displayRecordIndex.id !== '') {
            handleOpenLive();
            const mergedTimes = getStudentTimesById(dataa, displayRecordIndex.id);
            setTimeRecord(mergedTimes);
        }
    }, [displayRecordIndex]);


    return (
        <div className="flex w-[80rem] flex-col gap-8 p-4 max-h-[39.8rem]">
            {!err && isOpenLiveAttend &&
                <div className="overlay absolute top-0 left-0 right-0 bottom-0 bg-[rgba(55,55,56,0.5)] z-10"></div>
            }
            {!err && isOpenLiveAttend &&
                <div ref={liveViewRef} className="liveView absolute overflow-y-scroll top-0 left-10 right-0 bottom-0  m-auto w-[70%] h-[70%] rounded-lg bg-[#f2f2f2f2] p-5 z-10">
                    <div className="wrapper flex flex-col justify-between h-full">
                        <div className="wrapp">
                            <div className="top flex justify-between border-b-2 py-2">
                                <h2 className='font-semibold text-xl'>Course : {selectedCourse}</h2>
                                <h2 className='font-semibold text-xl'>Teacher : {dataa[4]}</h2>
                                <h2 className='font-bold text-xl cursor-pointer ' onClick={handleOpenLive} >X</h2>
                            </div>
                            <div className="bottom py-2 flex flex-wrap gap-3">
                                {/* loop area  */}
                                {timeRecord?.map((item, index) => (
                                    <div className="max-w-max bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                                        <a href="/">
                                            <img className="rounded-t-lg h-32 w-full bg-bottom object-cover" src={displayRecordIndex.img} alt="student img" />
                                        </a>
                                        <div className="px-2">
                                            <a href="/">
                                                <h5 className="mb-2 text-md font-semibold tracking-tight text-gray-900 dark:text-white">{displayRecordIndex.name}</h5>
                                            </a>
                                            <p className=" font-normal text-gray-700 dark:text-gray-400 text-12">Course:{selectedCourse} </p>
                                            <p className="mb-3 font-normal text-gray-700 dark:text-gray-400 text-12">ID:{displayRecordIndex.id}</p>

                                        </div>
                                        <div className={`inOut px-2 ${index % 2 === 0 ? 'bg-green-200' : 'bg-red-200'}`}>
                                            <span className='text-12 font-bold'>{index % 2 === 0 ? 'In' : 'Out'}:{item}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="top flex justify-between border-t-2 py-2">
                            <h2 className='font-semibold text-xl'>Class Duration : 1hr</h2>
                            <h2 className='font-semibold text-xl'>Time Spend : 30min</h2>
                            <h2 className={`font-semibold text-xl p-1 px-2 rounded-md text-white ${displayRecordIndex.attend > 50 ? "bg-green-500" : "bg-red-500"}`}>Status :{displayRecordIndex.attend > 50 ? "Present" : "Absent"} </h2>
                        </div>
                    </div>
                </div>
            }
            <span className='text-2xl font-bold'>Attendance Management</span>
            {!err && <div className="w-full flex gap-10 ">
                <Select type={"simple select"} label={"Course"} name={!props.id && "course"} setSelectedCourse={setSelectedCourse} stId={props.id} />
            </div>}
            <div className="w-full flex justify-between items-center">
                {!props.id && !err && selectedCourse && <div className="right flex items-center border-1 rounded-lg p-1 border-[#6956E5] gap-3">
                    <input type="text" placeholder='enter student id..' className='w-72 focus:outline-none searchInput' onKeyPress={handleKeyPress} />
                    <img src="/icons/search.svg" alt="searchIcon" className='w-4 cursor-pointer' onClick={handleSearch} />
                </div>}
                <span className={searchId !== '' && 'bg-[#6956E5] text-white py-1 px-3 w-22'}>{searchId === 'no record!' || searchId === '' ? searchId : 'founded'}</span>
            </div>
            {!err && selectedCourse && <div className="p-5 border-t-1 overflow-y-scroll">
                <Table dataArray={data} tableHeading={tableHeading} setDisplayRecordIndex={setDisplayRecordIndex} styles={"p-3"} search_id={searchId} />
            </div>}
            {err &&
                <div className="w-full bg-red-200 flex justify-between p-2 rounded-md">
                    <span>{err}</span>
                    <button className='font-bold text-lg' onClick={() => { setError(''); setSelectedCourse(null); setIsOpenLiveAttend(false) }}>X</button>
                </div>

            }
        </div>
    )
}

export default AttendancePage
