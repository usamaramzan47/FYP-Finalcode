import React, { useEffect, useState, useContext } from 'react'
import { AuthContext } from '../../context/AuthContext';
import AttendancePage from './AttendancePage';


function StudentAttendance() {

    const { currentUser } = useContext(AuthContext);
    const [id, setId] = useState('');


    // read ID from email address
    const handleExtractId = (email) => {
        if (typeof email !== 'string') {
            console.error('Email is not a string:', email);
            return;
        }

        // Trim the email to remove any leading or trailing spaces
        const trimmedEmail = email.trim();
        const atIndex = trimmedEmail.indexOf('@');
        if (atIndex === -1) {
            console.error('Invalid email format, "@" not found:', trimmedEmail);
            return;
        }

        const extractedId = trimmedEmail.substring(0, atIndex);
        const capitalizedId = capitalizeFirstChar(extractedId);
        setId(capitalizedId);
    };

    const capitalizeFirstChar = (str) => {
        if (typeof str !== 'string' || str.length === 0) {
            return str; // handle invalid input
        }
        return str.charAt(0).toUpperCase() + str.slice(1);
    };

    useEffect(() => {
        if (!currentUser) {
            console.log("User is not authenticated");
            return;
        }
        handleExtractId(currentUser.email);
    }, [currentUser]);

    return (
        <div className="">
            {id && <AttendancePage id={id} />}
        </div>
    )
}

export default StudentAttendance
