import React, { useEffect, useState, useContext } from 'react'
import { getDatabase, ref, get, onValue } from 'firebase/database';
import { AuthContext } from '../../context/AuthContext';


function Mycourses() {

    const { currentUser } = useContext(AuthContext);
    const [err, setError] = useState('');
    const [teacherNames, setTeacherNames] = useState([]);
    const [data, setData] = useState(null);

    const [id, setId] = useState('');


    // read ID from email address
    const handleExtractId = (email) => {
        if (typeof email !== 'string') {
            console.error('Email is not a string:', email);
            return;
        }

        // Trim the email to remove any leading or trailing spaces
        const trimmedEmail = email.trim();
        const atIndex = trimmedEmail.indexOf('@');
        if (atIndex === -1) {
            console.error('Invalid email format, "@" not found:', trimmedEmail);
            return;
        }

        const extractedId = trimmedEmail.substring(0, atIndex);
        const capitalizedId = capitalizeFirstChar(extractedId);
        setId(capitalizedId);
    };

    const capitalizeFirstChar = (str) => {
        if (typeof str !== 'string' || str.length === 0) {
            return str; // handle invalid input
        }
        return str.charAt(0).toUpperCase() + str.slice(1);
    };

    useEffect(() => {
        if (!currentUser) {
            console.log("User is not authenticated");
            return;
        }
        handleExtractId(currentUser.email);
    }, [currentUser]);

    useEffect(() => {
        if (!id) {
            // console.log("ID not set yet");
            return;
        }
        const database = getDatabase();
        const dataRef = ref(database, `students/${id}`); // Adjust the path to where your data is located in the database

        //fetch student Data
        const unsubscribe = onValue(dataRef, async (snapshot) => {
            const data = snapshot.val();
            setData(data);
            //fetch courses
            try {
                // Fetch the courses and extract teacher names
                const coursesRef = ref(database, `courses`);
                const coursesSnapshot = await get(coursesRef);
                if (!coursesSnapshot.exists()) {
                    console.log("No courses data available");
                    setError("No courses data available");
                    return;
                }

                const coursesData = coursesSnapshot.val();
                const teachers = data?.courses
                    .map(courseName => {
                        const course = Object.values(coursesData).find(course => course.courseId === courseName);
                        return course ? course.teacherName : null;
                    })
                    .filter(teacherName => teacherName !== null);

                setTeacherNames(teachers);
            } catch (error) {
                setError("Error fetching Courses data.", error.message);
            }
        }, (error) => {
            setError("Error fetching data.", error.message);
        });

        return () => unsubscribe(); // Clean up the listener on unmount
    }, [id]);

    return (
        <div>
            <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">
                                Course Name
                            </th>
                            <th scope="col" className="px-6 py-3">
                                Instructor Name
                            </th>
                            <th scope="col" className="px-6 py-3">
                                Room No.
                            </th>
                            <th scope="col" className="px-6 py-3">
                                Building
                            </th>
                            <th scope="col" className="px-6 py-3">
                                <span className="sr-only">Edit</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        {!err && data?.courses.map((item, index) => (

                            <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    {item}
                                </th>
                                <td className="px-6 py-4">
                                    {teacherNames[index]}
                                </td>
                                <td className="px-6 py-4">
                                    318
                                </td>
                                <td className="px-6 py-4">
                                    STD
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

        </div>
    )
}

export default Mycourses
