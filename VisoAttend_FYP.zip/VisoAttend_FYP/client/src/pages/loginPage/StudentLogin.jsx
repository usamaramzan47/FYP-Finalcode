import React, { useState } from 'react';
import Button from '../../components/global/button/Button';
import { useNavigate } from 'react-router-dom'
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from '../../firebase.js';
import Prompt from '../../components/global/promptMsg/PromptMsg.jsx';

function Login() {
  const navigate = useNavigate();
  const [err, setErr] = useState(false)
  const [errMsg, setErrMsg] = useState("")

  const handleSubmit = async (e) => {
    setErr(true)
    setErrMsg("verifying user...")
    e.preventDefault();
    const email = e.target[0].value
    const password = e.target[1].value
    // if (email === 'usama@viso.com' && password === 'usama@123') {
    //   navigate("/")
    //   seterr(false)
    // }
    // else seterr(true)
    try {
      if (email === 'admin@visio.com' || email === 'Admin@visio.com') {
        setErr(true)
        setErrMsg("no user exist...")
        //navigate("/login")
      } else {

        await signInWithEmailAndPassword(auth, email, password);
        navigate("/dashboard")
      }
    }
    catch (error) {
      setErr(true)
      setErrMsg(error.code)
    }


  }

  return (
    <div className=' bg-[#f8f8f8] h-screen flex justify-center'>
      <div className=" bg-[#6956E5] flex w-[60rem] h-[40rem] justify-between m-auto">
        <div className="hidden left flex-1 sm:flex flex-col justify-between">
          <div className="textField text-white flex flex-col h-[40%] lg:h-[50%] pl-9 justify-center gap-2">
            <h1 className='font-extrabold text-2xl sm:text-4xl lg:text-5xl'>Welcome To Student Portal</h1>
            <span className='text-14 ml-2'>Login To access the Dashboard!</span>
          </div>
          <img src="/images/loginsvg.svg" alt="login" />
        </div>
        <div className="right border-[#6956E5] border-y-[8px] sm:border-none bg-white flex-1 flex flex-col gap-10">
          <div className="title h-[22%] flex items-end justify-center">
            <h1 className="title text-[#6956E5] text-3xl xsm:text-4xl lg:text-5xl font-extrabold tracking-wide">VisioAttend</h1>
          </div>
          <form className="box p-5 pl-8 flex flex-col gap-6" onSubmit={handleSubmit}>
            <span className="title font-bold text-lg">Login</span>
            <div className="input flex flex-col gap-1">
              <label htmlFor="#" className='text-md font-semibold'>user id</label>
              <input type="email" name='id' required placeholder='enter id or email' className='w-[80%] p-2 bg-[#f8f8f8] rounded-md outline-none focus:ring-2' />
            </div>
            <div className="input flex flex-col gap-1">
              <label htmlFor="#" className='text-md font-semibold '>password</label>
              <input type="password" name='password' required placeholder='enter password' className='w-[80%] p-2 bg-[#f8f8f8] rounded-md outline-none focus:ring-2' />
            </div>
            <div className="link w-[80%] flex justify-end">
              <a href="/" className='text-14 text-[#6956E5] font-semibold underline'>forget password ?</a>
            </div>
            <Button type={"primary"} label={"Login"} styles={"w-20"} />
          </form>
        </div>
      </div>
      {err && <Prompt message={errMsg} confirmed={setErr} />}
    </div>
  )
}

export default Login
