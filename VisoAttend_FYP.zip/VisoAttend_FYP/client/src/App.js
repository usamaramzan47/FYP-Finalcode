import React, { useContext } from 'react';
import Navbar from './components/global/navbar/Navbar.jsx';
import Sidebar from './components/global/sidebar/Sidebar.jsx';
import Dashboard from './pages/dashboard/Dashboard.jsx';
import Login from './pages/loginPage/Login.jsx';
import StudentLogin from './pages/loginPage/StudentLogin.jsx';
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from "react-router-dom";
import Timeslot from './pages/timeslots/Timeslot.jsx';
import Enrollment from './pages/enrollment/Enrollment.jsx';
import ReservedRooms from './pages/reservedrooms/ReservedRooms.jsx';
import AttendancePage from './pages/attendancePage/AttendancePage.jsx';
import { AuthContext } from './context/AuthContext.js';
import StudentDashboard from './pages/dashboard/StudentDashboard.jsx'
import CreateTimeslots from './pages/timeslots/CreateTimeslots.jsx';
import Mycourses from './pages/courses/Mycourses.jsx';
import StudentAttendance from './pages/attendancePage/StudentAttendance.jsx';

function App() {
  return (
    <div className="w-full App">
      <Router>
        <AppContent />
      </Router>
    </div>
  );
}

function AppContent() {
  const { currentUser, authId, loading } = useContext(AuthContext);
  const location = useLocation();


  const ProtectedRoute = ({ children }) => {
    if (!currentUser) return <Navigate to="/login" replace />;
    return children;
  };

  const isLoginPage = location.pathname === '/adminLogin' || location.pathname === '/login';

  if (loading) {
    return (
      <div className="w-full h-screen flex items-center justify-center">
        <h1 className="text-3xl font-bold">loading...</h1>
      </div>
    );
  }

  return (
    <>
      {!isLoginPage && (

        <ProtectedRoute>
          <div className='flex w-full'>
            <Sidebar />
            <div className='flex w-full flex-col ml-[16%]'>
              <Navbar />
              {currentUser?.uid !== authId &&
                <div className='max-w-full mt-[7%]'>
                  <Routes>
                    <Route exact path="/dashboard" element={<StudentDashboard />} />
                    <Route exact path="/mycourses" element={<Mycourses />} />
                    <Route exact path="/myattendance" element={<StudentAttendance />} />
                    {/* <Route exact path="/*" element={<NotAuthorized />} /> */}
                  </Routes>
                </div>}
              {currentUser?.uid === authId && <div className="max-w-full mt-[7%]">
                <Routes>
                  <Route exact path="/" element={<Dashboard />} />
                  <Route exact path="/timeslots" element={<Timeslot />} />
                  <Route exact path="/enrollment" element={<Enrollment />} />
                  <Route exact path="/reservedRooms" element={<ReservedRooms />} />
                  <Route exact path="/attendance" element={<AttendancePage />} />
                  <Route exact path="/createTimeslots" element={<CreateTimeslots />} />
                  {/* Add more routes as needed */}
                </Routes>
              </div>}
            </div>
          </div>

        </ProtectedRoute>
      )}

      {isLoginPage && (

        <Routes>
          <Route path="/login" element={<StudentLogin />} />
          <Route
            path="/adminLogin"
            element={
              <Login />
            }
          />
        </Routes>
      )}
    </>
  );
}

function NotAuthorized() {
  return (
    <div className="w-full h-screen flex items-center justify-center">
      <h1 className="text-3xl font-bold">You are not authorized to view this page. Please log in.</h1>
    </div>
  );
}
export default App;
