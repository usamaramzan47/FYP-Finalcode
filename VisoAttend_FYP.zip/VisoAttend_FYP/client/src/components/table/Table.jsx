import React from 'react';
import './style.css';

function Table(props) {

    return (
        <table className={props.styles}>
            <thead>
                <tr>
                    {props.tableHeading.map(item => (
                        <th key={item.id} className='bg-blue-500 text-white min-w-20 h-10 border-2'>
                            <div className="flex flex-col">
                                {item.label}<span className='text-[9px] font-normal'>{item.date}</span>
                            </div>
                        </th>
                    ))
                    }
                </tr>
            </thead>
            <tbody>
                {!props.dataArray[0]?.attendance ? props.dataArray.map(item => (
                    <tr key={item.id} className='even:bg-gray-50'>
                        <td>
                            <div className="wrapper flex gap-2 items-center">
                                {item.img ? <img src={item.img} alt="user" className='w-10 h-10 rounded-full object-cover' /> : ""}
                                <span>{item.name || item.building}</span>
                            </div>
                        </td>
                        <td>{item.mail || item.roomNumber}</td>
                        <td>{item.joinDate || item.timeSlot}</td>
                        {item.designation && <td>{item.designation}</td>}
                    </tr>
                ))
                    : props.dataArray.map(item => (
                        <tr key={item.id} className={item.id === props.search_id ? 'bg-yellow-200' : 'even:bg-gray-50'}>
                            <td>
                                <span>{item.id}</span>
                            </td>
                            <td className='min-w-32'>
                                <span>{item.name}</span>
                            </td>
                            {
                                item.attendance?.map((attend, index) => (
                                    <td key={index}>
                                        <div
                                            className={`flex flex-col p-2 ${attend === '-' ? '' : 'cursor-pointer hover:bg-blue-100'}`}
                                            onClick={attend === '-' ? null : () => props.setDisplayRecordIndex({ id: item.id, index, name: item.name, img: item.photoURL, attend })}
                                        >
                                            <span className={`${attend >= 50 ? '' : 'text-red-400'}`}>
                                                {attend >= 50 ? 'P' : (attend === '-' ? 'No record' : 'A')}
                                            </span>
                                            <span className='text-[9px]'>{attend === '-' ? '-----' : `${attend}%`}</span>
                                        </div>
                                    </td>
                                ))
                            }
                        </tr>
                    ))
                }
            </tbody>
        </table>

    );
}
export default Table;
