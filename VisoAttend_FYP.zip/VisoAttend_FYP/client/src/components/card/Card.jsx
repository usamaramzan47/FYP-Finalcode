import React from 'react'

function Card({type, title, value, total, img} ) {

  return (
    <div className={`box w-64 h-40 ${type  === "primary" ? "bg-[#f8f8f8]" : "bg-[#ffffff]"} flex rounded-md shadow-md shadow-zinc-400 `}>
      <div className="left flex-1 mt-2 pl-2">
        <span className={`text-14 ${type === "primary" ? "text-[#6956E5]" : "text-[#878787]"} font-semibold`}>{title}</span>
        <div className="wrapper flex h-full items-center justify-center">
        <div className={`total text-4xl font-bold ${type === "primary" ? "text-[#6956E5]" : "text-[#878787]"}`}>{value}{total ?<span className='text-12 text-[black]'>{total}</span> :""} </div>
        </div>
      </div>
      <div className="right flex items-center flex-1 justify-center bg-[#6956E5] rounded-l-full ml-8">
        <img src={img} alt="classroom"  className='w-14'/>
      </div>
    </div>
  )
}

export default Card
