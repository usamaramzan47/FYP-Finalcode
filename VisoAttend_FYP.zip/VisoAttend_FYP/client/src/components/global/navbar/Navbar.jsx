import React, { useContext, useState } from 'react'
import { signOut } from "firebase/auth";
import { auth } from '../../../firebase.js';
import { AuthContext } from '../../../context/AuthContext.js';

function Navbar() {

  const { currentUser } = useContext(AuthContext);

  const title = {
    name: currentUser?.displayName,
    wish: "Hope you have a good day"
  }

  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className='p-4 w-[84%] flex justify-between border-b-1 fixed bg-white z-10'>
      <div className="left flex flex-col items-end gap-1">
        <div className="wrapper flex flex-col">
          <span className="text-2xl font-bold">{title.name} 👋</span>
          <span className='text-[10px] font-semibold text-[#878787] pl-1'>{title.wish}</span>
        </div>
      </div>
      <div className="right flex items-center gap-8 relative right-6">
        <img src="/icons/search.svg" alt="icon" className='w-4' />
        <img src="/icons/bell.svg" alt="icon" className='w-4' />
        <div className="user flex items-center gap-1">
          <img src={currentUser?.photoURL} alt="img" className='w-8 h-8 rounded-full object-cover' />
          <img src="/icons/arrowDown.svg" alt="icon" className='cursor-pointer' onClick={() => setIsOpen(!isOpen)} />
        </div>

        <section className={`${isOpen ? 'flex' : 'hidden'} absolute top-12 right-0 bg-[#6956E5] text-white rounded`}>
          <ul className='px-6 py-4 flex flex-col gap-4'>
            <div className="flex gap-2 border-b-1 border-black p-1">
              <img src="/icons/bell.svg" alt="" className='w-4' />
              <li className='cursor-pointer'>notification</li>
            </div>
            <div className="flex gap-2 border-b-1 border-black p-1">
              <img src="/icons/logout.svg" alt="" className='w-4' />
              <li className='cursor-pointer' onClick={() => signOut(auth)}>logout</li>
            </div>

          </ul>
        </section>
      </div>
    </div>
  )
}

export default Navbar
