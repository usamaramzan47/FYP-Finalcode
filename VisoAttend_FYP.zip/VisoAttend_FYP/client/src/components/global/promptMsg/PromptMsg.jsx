
const Prompt = ({ message, confirmed}) => {

  const handleClose = () => {
    confirmed(!confirmed);
  };

  return (
    <div className="fixed inset-0 flex justify-center items-center bg-gray-50 bg-opacity-75 backdrop-blur-sm">
        <div className="fixed p-10 flex flex-col gap-5 bg-gray-800 text-white rounded-lg shadow-lg max-w-[30%]">
          <p>{message}</p>
          <button
            onClick={handleClose}
            className="mt-2 px-4 py-2 bg-blue-500 text-white rounded-md focus:outline-none focus:bg-blue-600"
          >
            Close
          </button>
        </div>
    </div>
  );
};

export default Prompt;
