import React, { useContext } from 'react'
import { Link } from 'react-router-dom';
import { signOut } from "firebase/auth";
import { auth } from '../../../firebase.js';
import { AuthContext } from '../../../context/AuthContext.js';
function Sidebar() {

    const { currentUser, authId } = useContext(AuthContext);
    return (
        <div className="left p-8 h-full bg-[#f9f9f9] w-[16%]  fixed z-10 border-r-1">
            <div className="logo flex items-center gap-1 ">
                <img src="/images/logo.svg" alt="logo" className='w-6' />
                <Link to={"/"}>
                    <span className='text-[#6956E5] font-semibold'>VisioAttend</span>
                </Link>
            </div>
            {currentUser?.uid === authId &&
                <menu className='mt-20 flex flex-col gap-8'>
                    <ul className='flex flex-col gap-8'>
                        <li className='flex gap-2 items-center'>
                            <img src="/icons/dashboard.svg" alt="icon" className='w-4' />
                            <Link to={"/"}>
                                <span className='font-semibold text-[#6956E5]'>Dashboard</span>
                            </Link>
                        </li>
                        <li className='flex gap-2 items-center'>
                            <img src="/icons/addRoom.svg" alt="icon" className='w-4' />
                            <Link to={"/reservedrooms"}>
                                <span className='font-semibold text-[#878787]'>Reserved Rooms</span>
                            </Link>
                        </li>
                        <li className='flex gap-2 items-center'>
                            <img src="/icons/addParticipants.svg" alt="icon" className='w-4' />
                            <Link to={"/enrollment"}>
                                <span className='font-semibold text-[#878787]'>Enrollment</span>
                            </Link>
                        </li>
                        <li className='flex gap-2 items-center'>
                            <img src="/icons/briefcase.svg" alt="icon" className='w-4' />
                            <Link to={"/timeslots"}>
                                <span className='font-semibold text-[#878787]'>Manage Timeslots</span>
                            </Link>
                        </li>
                        <li className='flex gap-2 items-center'>
                            <img src="/icons/attendance.svg" alt="icon" className='w-4' />
                            <Link to={"/attendance"}>
                                <span className='font-semibold text-[#878787]'>Attendance View</span>
                            </Link>
                        </li>
                    </ul>
                    <hr />
                    <ul className='flex flex-col gap-8'>
                        <li className='flex gap-2 items-center'>
                            <img src="/icons/newTimeslot.svg" alt="icon" className='w-5' />
                            <Link to={"/createTimeslots"}>
                                <span className='font-semibold text-[#878787]'>create Timeslots</span>
                            </Link>
                        </li>
                        <li className='flex gap-2 items-center'>
                            <img src="/icons/folder.svg" alt="icon" className='w-4' />
                            <Link to={"/tasks"}>
                                <span className='font-semibold text-[#878787]'>Tasks</span>
                            </Link>
                        </li>
                        <li className='flex gap-2 items-center'>
                            <img src="/icons/setting.svg" alt="icon" className='w-4' />
                            <Link to={"/setting"}>
                                <span className='font-semibold text-[#878787]'>Settings</span>
                            </Link>
                        </li>
                        <li className='flex gap-2 items-center cursor-pointer'>
                            <img src="/icons/logout.svg" alt="icon" className='w-4' />
                            <span className='font-semibold text-[#878787]' onClick={() => signOut(auth)}>logout</span>
                        </li>
                    </ul>
                </menu>

            }
            {currentUser?.uid !== authId &&
                <menu className='mt-20 flex flex-col gap-8'>
                    <ul className='flex flex-col gap-8'>
                        <li className='flex gap-2 items-center'>
                            <img src="/icons/dashboard.svg" alt="icon" className='w-4' />
                            <Link to={"/dashboard"}>
                                <span className='font-semibold text-[#6956E5]'>Dashboard</span>
                            </Link>
                        </li>

                        <li className='flex gap-2 items-center'>
                            <img src="/icons/folder.svg" alt="icon" className='w-4' />
                            <Link to={"/mycourses"}>
                                <span className='font-semibold text-[#878787]'>My Courses</span>
                            </Link>
                        </li>
                        <li className='flex gap-2 items-center'>
                            <img src="/icons/attendance.svg" alt="icon" className='w-4' />
                            <Link to={"/myattendance"}>
                                <span className='font-semibold text-[#878787]'>Attendance View</span>
                            </Link>
                        </li>
                    </ul>
                    <hr />
                    <ul className='flex flex-col gap-8'>

                        <li className='flex gap-2 items-center cursor-pointer'>
                            <img src="/icons/logout.svg" alt="icon" className='w-4' />
                            <span className='font-semibold text-[#878787]' onClick={() => signOut(auth)}>logout</span>
                        </li>
                    </ul>
                </menu>
            }
        </div>
    )
}

export default Sidebar
