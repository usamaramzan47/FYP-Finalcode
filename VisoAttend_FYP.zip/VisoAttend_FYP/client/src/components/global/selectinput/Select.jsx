import React, { useState, useRef, useEffect } from 'react';
import { getDatabase, onValue, ref as dbRef } from 'firebase/database';

const Select = ({ label, type, name, placeholder, styles, onSelectionChange, setSelectedCourse, stId }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);
  // get courses names
  const [courseIds, setCourseIds] = useState([]);


  const containerRef = useRef(null);

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleCheckboxChange = (event) => {
    const value = event.target.value;
    let updatedSelectedItems;
    if (event.target.checked) {
      updatedSelectedItems = [...selectedItems, value];
    } else {
      updatedSelectedItems = selectedItems.filter(item => item !== value);
    }
    setSelectedItems(updatedSelectedItems);
    onSelectionChange(updatedSelectedItems);
  };

  const handleClickOutside = (event) => {
    if (containerRef.current && !containerRef.current.contains(event.target)) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    handleSelection();
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);



  const handleSelection = async () => {
    try {
      const database = getDatabase();

      if (name === 'course') {
        const coursesRef = dbRef(database, 'courses');
        onValue(coursesRef, (snapshot) => {
          const coursesData = snapshot.val();
          if (coursesData) {
            const ids = Object.keys(coursesData);
            setCourseIds(ids);
          } else {
            console.log("No data found in the 'courses' node!");
          }
        });
      }
      else if (stId) {
        const coursesRef = dbRef(database, `students/${stId}`); // Adjust the path to where your data is located in the database


        onValue(coursesRef, (snapshot) => {
          const coursesData = snapshot.val();
          if (coursesData) {

            setCourseIds(coursesData?.courses);
          } else {
            console.log("No data found in the 'student Courses' node!");
          }
        });
      }
      else if (name === 'room') {
        const coursesRef = dbRef(database, 'ReserveRoom');
        onValue(coursesRef, (snapshot) => {
          const coursesData = snapshot.val();
          if (coursesData) {
            const ids = Object.keys(coursesData);
            setCourseIds(ids);
          } else {
            console.log("No data found in the 'ReservedRoom' node!");
          }
        });
      }
      else if (name === 'teacher') {
        const coursesRef = dbRef(database, 'courses');
        onValue(coursesRef, (snapshot) => {
          const coursesData = snapshot.val();
          if (coursesData) {
            const ids = Object.keys(coursesData);
            const names = ids.map(courseId => {
              const course = coursesData[courseId];
              return course.teacherName;
            }).filter(name => name); // Filter out any undefined or null values
            setCourseIds(names);
          } else {
            console.log("No data found in the 'courses' node!");
          }
        });
      }
      else if (name === 'timeslot') {
        const coursesRef = dbRef(database, 'timeslots');
        onValue(coursesRef, (snapshot) => {
          const coursesData = snapshot.val();
          if (coursesData) {
            // Transform the data into 'startTime - endTime' format
            const transformedData = Object.values(coursesData).map(slot => `${slot.startTime} - ${slot.endTime}`);
            setCourseIds(transformedData);
          } else {
            console.log("No data found in the 'courses' node!");
          }
        });
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleChange = (e) => {
    if (setSelectedCourse)
      setSelectedCourse(e.target.value);
    else
      return null;
  };


  return (
    <div className="flex flex-col" ref={containerRef}>
      <label htmlFor={name} className='text-14 text-[#979696] font-semibold'>{label}</label>

      {type === 'select' && (
        <div className="relative inline-block text-left">
          <div>
            <button
              type="button"
              onClick={handleToggle}
              className={`inline-flex justify-between w-64 rounded-md border border-gray-300 bg-white px-4 py-2 text-sm leading-5 font-medium text-gray-700 focus:outline-none focus:border-indigo-300 focus:shadow-outline-indigo active:bg-gray-50 active:text-gray-800 transition ease-in-out duration-150 ${styles}`}
            >
              {selectedItems.length > 0 ? `${selectedItems.length} selected` : '-- Select --'}
              <svg
                className="-mr-1 ml-2 h-5 w-5"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
                aria-hidden="true"
              >
                <path
                  fillRule="evenodd"
                  d="M6.293 7.293a1 1 0 011.414 0L10 9.586l2.293-2.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"
                  clipRule="evenodd"
                />
              </svg>
            </button>
          </div>
          {isOpen && (
            <div className="absolute mt-1 w-64 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
              <div className="py-1">
                {courseIds.map((item) => (
                  <label key={item} className="flex items-center py-2 px-4 text-sm">
                    <input
                      type="checkbox"
                      value={item}
                      checked={selectedItems.includes(item)}
                      onChange={handleCheckboxChange}
                      className="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out"
                    />
                    <span className="ml-2">{item}</span>
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
      {/* for simple selection  */}
      {type === 'simple select' && (
        <div className="relative w-max">
          <select
            name={name}
            id=""
            className='appearance-none w-full px-5 py-2 border-2 rounded-lg border-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-700 cursor-pointer space-y-2'
            onChange={handleChange}
          >
            <option value="select" disabled selected className='py-2'>--select--</option>
            {courseIds.map((item) => (
              <option className='py-12 text-14 w-full px-2' value={item} key={item} >{item}</option>
            ))}
          </select>
        </div>
      )}

      {type === 'input' && (
        <input
          type={name === 'email' ? 'email' : name === 'password' ? 'password' : 'text'}
          id={name}
          name={name}
          required
          placeholder={placeholder}
          onChange={onSelectionChange}
          className={`p-2 border-l-8 border-1 border-[#6956E5] h-10 w-64 rounded-lg outline-none focus:ring-2 ${styles}`}
        />
      )}
    </div>
  );
};

export default Select;
