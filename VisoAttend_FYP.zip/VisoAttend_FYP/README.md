# VisoAttend_FYP
this is our FYP of marking attendance of students present in the class using the camera.

#Run
**step 1**: _npm i _
  this will install all the dependences in package.json file

**step 2** : _Run TailwindCSS command below in new terminal_
  npx tailwindcss -i ./src/index.css -o ./src/output.css --watch
  this will genrate the output file to your src/ folder that will keep track the tailwindCSS classes that you use in project
